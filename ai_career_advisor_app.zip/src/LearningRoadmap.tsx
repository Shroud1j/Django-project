interface Recommendations {
  recommendations: Array<{
    title: string;
    description: string;
    matchScore: number;
    salaryRange: string;
    requiredSkills: string[];
    growthOutlook: string;
    industry: string;
  }>;
  learningRoadmap: Array<{
    skill: string;
    priority: string;
    timeToLearn: string;
    resources: string[];
  }>;
  generatedAt: number;
}

interface Props {
  recommendations: Recommendations | null | undefined;
}

export function LearningRoadmap({ recommendations }: Props) {
  if (!recommendations || !recommendations.learningRoadmap) {
    return (
      <div className="text-center py-12">
        <div className="text-gray-400 text-6xl mb-4">🗺️</div>
        <h3 className="text-xl font-semibold text-gray-900 mb-2">No Learning Roadmap Yet</h3>
        <p className="text-gray-600">
          Generate career recommendations first to see your personalized learning roadmap.
        </p>
      </div>
    );
  }

  const priorityColors = {
    high: "bg-red-100 text-red-800 border-red-200",
    medium: "bg-yellow-100 text-yellow-800 border-yellow-200",
    low: "bg-green-100 text-green-800 border-green-200",
  };

  const priorityOrder = { high: 1, medium: 2, low: 3 };
  const sortedRoadmap = [...recommendations.learningRoadmap].sort(
    (a, b) => priorityOrder[a.priority as keyof typeof priorityOrder] - priorityOrder[b.priority as keyof typeof priorityOrder]
  );

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Your Learning Roadmap</h2>
        <p className="text-gray-600">
          Prioritized skills to develop based on your career goals
        </p>
      </div>

      <div className="grid gap-4">
        {sortedRoadmap.map((item, index) => (
          <div key={index} className="border border-gray-200 rounded-lg p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{item.skill}</h3>
                <div className="flex items-center gap-3">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${
                    priorityColors[item.priority as keyof typeof priorityColors]
                  }`}>
                    {item.priority.charAt(0).toUpperCase() + item.priority.slice(1)} Priority
                  </span>
                  <span className="text-sm text-gray-600">
                    ⏱️ {item.timeToLearn}
                  </span>
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-medium text-gray-900 mb-2">Recommended Resources</h4>
              <ul className="space-y-1">
                {item.resources.map((resource, resourceIndex) => (
                  <li key={resourceIndex} className="text-sm text-gray-700 flex items-center">
                    <span className="w-2 h-2 bg-blue-400 rounded-full mr-3 flex-shrink-0"></span>
                    {resource}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h3 className="font-medium text-blue-900 mb-2">💡 Learning Tips</h3>
        <ul className="text-sm text-blue-800 space-y-1">
          <li>• Focus on high-priority skills first for maximum career impact</li>
          <li>• Practice skills through real projects and portfolio building</li>
          <li>• Join communities and find mentors in your target field</li>
          <li>• Set specific learning goals and track your progress</li>
        </ul>
      </div>
    </div>
  );
}
