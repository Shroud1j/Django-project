import { useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { toast } from "sonner";

export function SavedCareers() {
  const savedCareers = useQuery(api.careers.getSavedCareers);
  const deleteSavedCareer = useMutation(api.careers.deleteSavedCareer);

  const handleDelete = async (careerId: any) => {
    try {
      await deleteSavedCareer({ careerId });
      toast.success("Career removed from saved list");
    } catch (error) {
      toast.error("Failed to remove career");
    }
  };

  if (!savedCareers || savedCareers.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="text-gray-400 text-6xl mb-4">💾</div>
        <h3 className="text-xl font-semibold text-gray-900 mb-2">No Saved Careers Yet</h3>
        <p className="text-gray-600">
          Save interesting career recommendations to review them later.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Saved Careers</h2>
        <p className="text-gray-600">
          Your bookmarked career opportunities
        </p>
      </div>

      <div className="grid gap-4">
        {savedCareers.map((career) => (
          <div key={career._id} className="border border-gray-200 rounded-lg p-6">
            <div className="flex justify-between items-start mb-4">
              <div className="flex-1">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{career.careerTitle}</h3>
                <div className="flex items-center gap-4 mb-3">
                  <span className="text-sm text-gray-600">{career.industry}</span>
                  <span className="text-sm font-medium text-green-600">{career.salaryRange}</span>
                </div>
              </div>
              <button
                onClick={() => handleDelete(career._id)}
                className="ml-4 px-3 py-1 text-sm bg-red-100 text-red-700 rounded hover:bg-red-200"
              >
                🗑️ Remove
              </button>
            </div>

            <p className="text-gray-700 mb-4">{career.description}</p>

            {career.notes && (
              <div className="bg-yellow-50 border border-yellow-200 rounded p-3">
                <h4 className="font-medium text-yellow-900 mb-1">Notes</h4>
                <p className="text-sm text-yellow-800">{career.notes}</p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
