import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { ProfileForm } from "./ProfileForm";
import { CareerRecommendations } from "./CareerRecommendations";
import { SavedCareers } from "./SavedCareers";
import { LearningRoadmap } from "./LearningRoadmap";

export function Dashboard() {
  const [activeTab, setActiveTab] = useState("profile");
  const profile = useQuery(api.profiles.getUserProfile);
  const recommendations = useQuery(api.careers.getCareerRecommendations);

  const tabs = [
    { id: "profile", label: "Profile", icon: "👤" },
    { id: "recommendations", label: "Career Recommendations", icon: "🎯" },
    { id: "roadmap", label: "Learning Roadmap", icon: "🗺️" },
    { id: "saved", label: "Saved Careers", icon: "💾" },
  ];

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Your Career Dashboard</h1>
        <p className="text-gray-600">
          Build your profile and get personalized AI-powered career advice
        </p>
      </div>

      {/* Tab Navigation */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8 justify-center">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`py-2 px-1 border-b-2 font-medium text-sm whitespace-nowrap ${
                activeTab === tab.id
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              <span className="mr-2">{tab.icon}</span>
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}
      <div className="bg-white rounded-lg shadow-sm border p-6">
        {activeTab === "profile" && <ProfileForm />}
        {activeTab === "recommendations" && (
          <CareerRecommendations 
            profile={profile} 
            recommendations={recommendations} 
          />
        )}
        {activeTab === "roadmap" && (
          <LearningRoadmap recommendations={recommendations} />
        )}
        {activeTab === "saved" && <SavedCareers />}
      </div>
    </div>
  );
}
