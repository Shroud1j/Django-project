import { useState } from "react";
import { useMutation, useAction } from "convex/react";
import { api } from "../convex/_generated/api";
import { toast } from "sonner";

import { Id } from "../convex/_generated/dataModel";

interface Profile {
  _id: Id<"userProfiles">;
  skills: string[];
  interests: string[];
  goals: string;
  experienceLevel: string;
  educationLevel: string;
  preferredIndustries: string[];
  location?: string;
  salaryExpectation?: string;
}

interface Recommendation {
  title: string;
  description: string;
  matchScore: number;
  salaryRange: string;
  requiredSkills: string[];
  growthOutlook: string;
  industry: string;
}

interface Recommendations {
  recommendations: Recommendation[];
  learningRoadmap: Array<{
    skill: string;
    priority: string;
    timeToLearn: string;
    resources: string[];
  }>;
  generatedAt: number;
}

interface Props {
  profile: Profile | null | undefined;
  recommendations: Recommendations | null | undefined;
}

export function CareerRecommendations({ profile, recommendations }: Props) {
  const [isGenerating, setIsGenerating] = useState(false);
  const generateCareerAdvice = useAction(api.careers.generateCareerAdvice);
  const saveCareer = useMutation(api.careers.saveCareer);

  const handleGenerateRecommendations = async () => {
    if (!profile) {
      toast.error("Please complete your profile first");
      return;
    }

    setIsGenerating(true);
    try {
      await generateCareerAdvice({ profileId: profile._id });
      toast.success("Career recommendations generated!");
    } catch (error) {
      toast.error("Failed to generate recommendations");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSaveCareer = async (recommendation: Recommendation) => {
    try {
      await saveCareer({
        careerTitle: recommendation.title,
        description: recommendation.description,
        salaryRange: recommendation.salaryRange,
        industry: recommendation.industry,
      });
      toast.success("Career saved!");
    } catch (error) {
      toast.error("Failed to save career");
    }
  };

  if (!profile) {
    return (
      <div className="text-center py-12">
        <div className="text-gray-400 text-6xl mb-4">📝</div>
        <h3 className="text-xl font-semibold text-gray-900 mb-2">Complete Your Profile First</h3>
        <p className="text-gray-600">
          Fill out your profile information to get personalized career recommendations.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Career Recommendations</h2>
        {!recommendations && (
          <p className="text-gray-600 mb-6">
            Get AI-powered career recommendations based on your profile
          </p>
        )}
        
        <button
          onClick={handleGenerateRecommendations}
          disabled={isGenerating}
          className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed font-medium"
        >
          {isGenerating ? (
            <>
              <div className="inline-block animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              Generating Recommendations...
            </>
          ) : (
            <>🎯 Generate New Recommendations</>
          )}
        </button>
      </div>

      {recommendations && (
        <div className="space-y-6">
          <div className="text-sm text-gray-500 text-center">
            Generated on {new Date(recommendations.generatedAt).toLocaleDateString()}
          </div>

          <div className="grid gap-6">
            {recommendations.recommendations.map((rec, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">{rec.title}</h3>
                    <div className="flex items-center gap-4 mb-3">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        {rec.matchScore}% Match
                      </span>
                      <span className="text-sm text-gray-600">{rec.industry}</span>
                      <span className="text-sm font-medium text-green-600">{rec.salaryRange}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => handleSaveCareer(rec)}
                    className="ml-4 px-3 py-1 text-sm bg-gray-100 text-gray-700 rounded hover:bg-gray-200"
                  >
                    💾 Save
                  </button>
                </div>

                <p className="text-gray-700 mb-4">{rec.description}</p>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Required Skills</h4>
                    <div className="flex flex-wrap gap-1">
                      {rec.requiredSkills.map((skill, skillIndex) => (
                        <span
                          key={skillIndex}
                          className="inline-block px-2 py-1 text-xs bg-gray-100 text-gray-700 rounded"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Growth Outlook</h4>
                    <span className={`inline-block px-2 py-1 text-xs rounded ${
                      rec.growthOutlook.toLowerCase() === 'excellent' ? 'bg-green-100 text-green-800' :
                      rec.growthOutlook.toLowerCase() === 'good' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-gray-100 text-gray-700'
                    }`}>
                      {rec.growthOutlook}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
