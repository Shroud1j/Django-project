import { v } from "convex/values";
import { query, mutation, action } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { api } from "./_generated/api";
import OpenAI from "openai";

const openai = new OpenAI({
  baseURL: process.env.CONVEX_OPENAI_BASE_URL,
  apiKey: process.env.CONVEX_OPENAI_API_KEY,
});

export const getCareerRecommendations = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }

    const recommendations = await ctx.db
      .query("careerRecommendations")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .first();

    return recommendations;
  },
});

export const generateCareerAdvice = action({
  args: {
    profileId: v.id("userProfiles"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated");
    }

    const profile = await ctx.runQuery(api.profiles.getUserProfile);
    if (!profile) {
      throw new Error("Profile not found");
    }

    const prompt = `As an AI career advisor, analyze this student profile and provide career recommendations:

Skills: ${profile.skills.join(", ")}
Interests: ${profile.interests.join(", ")}
Goals: ${profile.goals}
Experience Level: ${profile.experienceLevel}
Education Level: ${profile.educationLevel}
Preferred Industries: ${profile.preferredIndustries.join(", ")}
Location: ${profile.location || "Not specified"}
Salary Expectation: ${profile.salaryExpectation || "Not specified"}

Please provide:
1. 5 specific career recommendations with match scores (0-100), salary ranges, required skills, growth outlook, and industry
2. A learning roadmap with 8 skills to develop, priority levels, estimated time to learn, and resource suggestions

Format your response as JSON with this structure:
{
  "recommendations": [
    {
      "title": "Career Title",
      "description": "Brief description",
      "matchScore": 85,
      "salaryRange": "$60,000 - $90,000",
      "requiredSkills": ["skill1", "skill2"],
      "growthOutlook": "Excellent/Good/Fair",
      "industry": "Technology"
    }
  ],
  "learningRoadmap": [
    {
      "skill": "Skill Name",
      "priority": "high/medium/low",
      "timeToLearn": "3-6 months",
      "resources": ["Online courses", "Books", "Practice projects"]
    }
  ]
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.7,
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No response from AI");
    }

    try {
      const aiResponse = JSON.parse(content);
      
      // Save recommendations to database
      await ctx.runMutation(api.careers.saveRecommendations, {
        profileId: args.profileId,
        recommendations: aiResponse.recommendations,
        learningRoadmap: aiResponse.learningRoadmap,
      });

      return aiResponse;
    } catch (error) {
      throw new Error("Failed to parse AI response");
    }
  },
});

export const saveRecommendations = mutation({
  args: {
    profileId: v.id("userProfiles"),
    recommendations: v.array(v.object({
      title: v.string(),
      description: v.string(),
      matchScore: v.number(),
      salaryRange: v.string(),
      requiredSkills: v.array(v.string()),
      growthOutlook: v.string(),
      industry: v.string(),
    })),
    learningRoadmap: v.array(v.object({
      skill: v.string(),
      priority: v.string(),
      timeToLearn: v.string(),
      resources: v.array(v.string()),
    })),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated");
    }

    // Delete existing recommendations for this user
    const existing = await ctx.db
      .query("careerRecommendations")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    for (const rec of existing) {
      await ctx.db.delete(rec._id);
    }

    // Insert new recommendations
    return await ctx.db.insert("careerRecommendations", {
      userId,
      profileId: args.profileId,
      recommendations: args.recommendations,
      learningRoadmap: args.learningRoadmap,
      generatedAt: Date.now(),
    });
  },
});

export const saveCareer = mutation({
  args: {
    careerTitle: v.string(),
    description: v.string(),
    salaryRange: v.string(),
    industry: v.string(),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated");
    }

    return await ctx.db.insert("savedCareers", {
      userId,
      ...args,
    });
  },
});

export const getSavedCareers = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    return await ctx.db
      .query("savedCareers")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();
  },
});

export const deleteSavedCareer = mutation({
  args: { careerId: v.id("savedCareers") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated");
    }

    const career = await ctx.db.get(args.careerId);
    if (!career || career.userId !== userId) {
      throw new Error("Career not found or unauthorized");
    }

    await ctx.db.delete(args.careerId);
  },
});
