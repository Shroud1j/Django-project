import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getUserProfile = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }

    const profile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    return profile;
  },
});

export const createOrUpdateProfile = mutation({
  args: {
    skills: v.array(v.string()),
    interests: v.array(v.string()),
    goals: v.string(),
    experienceLevel: v.string(),
    educationLevel: v.string(),
    preferredIndustries: v.array(v.string()),
    location: v.optional(v.string()),
    salaryExpectation: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated");
    }

    const existingProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (existingProfile) {
      await ctx.db.patch(existingProfile._id, {
        skills: args.skills,
        interests: args.interests,
        goals: args.goals,
        experienceLevel: args.experienceLevel,
        educationLevel: args.educationLevel,
        preferredIndustries: args.preferredIndustries,
        location: args.location,
        salaryExpectation: args.salaryExpectation,
      });
      return existingProfile._id;
    } else {
      return await ctx.db.insert("userProfiles", {
        userId,
        ...args,
      });
    }
  },
});
