import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  userProfiles: defineTable({
    userId: v.id("users"),
    skills: v.array(v.string()),
    interests: v.array(v.string()),
    goals: v.string(),
    experienceLevel: v.string(), // "beginner", "intermediate", "advanced"
    educationLevel: v.string(),
    preferredIndustries: v.array(v.string()),
    location: v.optional(v.string()),
    salaryExpectation: v.optional(v.string()),
  }).index("by_user", ["userId"]),

  careerRecommendations: defineTable({
    userId: v.id("users"),
    profileId: v.id("userProfiles"),
    recommendations: v.array(v.object({
      title: v.string(),
      description: v.string(),
      matchScore: v.number(),
      salaryRange: v.string(),
      requiredSkills: v.array(v.string()),
      growthOutlook: v.string(),
      industry: v.string(),
    })),
    learningRoadmap: v.array(v.object({
      skill: v.string(),
      priority: v.string(), // "high", "medium", "low"
      timeToLearn: v.string(),
      resources: v.array(v.string()),
    })),
    generatedAt: v.number(),
  }).index("by_user", ["userId"]).index("by_profile", ["profileId"]),

  savedCareers: defineTable({
    userId: v.id("users"),
    careerTitle: v.string(),
    description: v.string(),
    salaryRange: v.string(),
    industry: v.string(),
    notes: v.optional(v.string()),
  }).index("by_user", ["userId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
